# Bootcamp Prep Online

## Minimum Viable Product

Users should be able to:

- [ ] Log in / Log out
- [ ] Contact Admin
- [ ] Complete chapters
- [ ] Keep track of progress

Course consist of:

- [ ] Ordered chapters

Chapters consists of:

- [ ] Ordered Lessons

Lessons consists of:

- [ ] Either:
  * Video Lecture
  * Text Doc (MD)
  * Quiz
- [ ] Have notes attached to them
