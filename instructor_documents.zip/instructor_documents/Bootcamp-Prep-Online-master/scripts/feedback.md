1.
What material did you review in the last hour? In other words, how far did get in the chapter in 7 days?

2.
What was unclear or difficult? (e.g. instructions, problems, videos, layout, etc.)

3.
What was clear or easy?

4.
Did you need to use additional resources? If so, which ones?

5.
How can we improve your experience? (e.g. structure, wording, instructions, problems, etc.)

6.
What were your favorite and least favorite parts of this chapter?

7.
How likely are you to recommend Bootcamp Prep to a friend from 1 to 10?
  1 - No, not at all
  10 - Yes, definitely

8.
How much would you be willing to pay for this course?

$250 to $500
$500 to $750
$750 to $1000
$1000 to $1250
$1250 to $1500
