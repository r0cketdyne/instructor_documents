What will the functions evaluate to?

```javascript
function foo (num) {
  if (num > 15) {
    return "Anthony";
  } else if (num < 15) {
    return "Winnie";
  } else {
    return "Ned";
  }
}

foo(20);
foo(15);
foo(5);
```
