Write a function `printN(num)` that will log the first `num` numbers to the screen (starting from 0).

Check this box when all the test cases are passing:
