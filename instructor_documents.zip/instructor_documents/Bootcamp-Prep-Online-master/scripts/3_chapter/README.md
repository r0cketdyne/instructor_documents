# Chapter 3: Control Flow

1. What is control flow?
2. Conditional I (`if`)
3. Conditional II (`else` and `else if`)
4. Conditional III (`switch` case)
5. Predict The Output (exercise)
6. Looping I (`for` loop)
7. PrintN (exercise)
8. Looping II (`while` loop)
9. Looping Keywords
10. PrintSkip5N + PrintStop5N (exercise)
11. Which loops are infinite? (exercise)
12. Common beginner mistakes
