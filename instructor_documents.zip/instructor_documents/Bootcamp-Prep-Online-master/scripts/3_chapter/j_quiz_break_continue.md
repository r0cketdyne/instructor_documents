Write a function `printNSkip5(num)` that will print all the numbers from 0 to `num - 1`. It should skips all numbers that are multiple of 5.

Write a function `printNStop5(num)` that will print all the numbers from 0 to `num - 1`. It should stop printing and end when it hits a number that is multiple of 5, except 0 (otherwise we wouldn't see anything).
