Identify the loops that will terminate (not result in an infinite loop):

```js
A)
for (var i = 0; i < 200; i -= 1) {
  //some code...
}

B)
var i = 2;

while (i > 40) {
  //some code...
  i += 1
}

C)
for (var i = 32; i >= 2; i -= 1) {
  //some code...
}


D)
var i = 1;

while (i === 20) {
  //some code...
  i += 2
}

E)
for (var i = 1; i !== 20; i += 2) {
  //some code...
}
```
