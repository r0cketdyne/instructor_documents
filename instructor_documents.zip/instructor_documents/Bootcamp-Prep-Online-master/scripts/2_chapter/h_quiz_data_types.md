Give each piece of data on the left the number associated with the data type it
belongs to. Numbers may be used more than once.

_ "Curie"
_ true
_ 3.14
_ NaN
_ null
_ ""
_ undefined

1. String
2. Number
3. Undefined
4. Null
5. Boolean
