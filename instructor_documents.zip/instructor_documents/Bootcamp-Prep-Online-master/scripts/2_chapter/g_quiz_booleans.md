Determine if each expression will evaluate to `true` or `false`. Try not to use your
computer!

true

true || false

(true && false) || true

true && !true

!(false || !false)

(40 > 5) && ((30 - 5) > 26)

"Anthony" === "anthony"

3939824 % 2 === 0

[order of operations][../notes/order_of_operations.md]
