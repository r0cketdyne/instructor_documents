# Chapter 2: Introduction To JavaScript

1. Introduction to JavaScript
2. Primitive Data Types (Overview)
3. `Numbers`  (`NaN` too)
4. `Strings`
5. `Undefined`
6. `Null`
7. `Boolean`
8. Documentation (Part 1)
9. Variables
10. What is a function? (Syntax)
11. sayHi (example)
12. QUIZ: timesThree (exercise)
13. return vs console.log
14. JavaScript Syntax Rules
