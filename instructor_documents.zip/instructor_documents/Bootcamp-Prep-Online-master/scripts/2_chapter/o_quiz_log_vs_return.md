What will the following functions print to the screen? return?

```javascript
function foo () {
  console.log("foo bar");
}

function bar () {
  console.log(123);
  return 123;
}

function boo () {
  return console.log(50);
}
```
