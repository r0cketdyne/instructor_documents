Implement this function. Be sure to test it with the examples!

``` js
/*
** timesThree
** Input: n, a number
** Output (return value): The product of n and 3
**
** Examples
** timesThree(-1) => -3
** timesThree(5) => 15
** timesThree(432) => 1296
*/
```
