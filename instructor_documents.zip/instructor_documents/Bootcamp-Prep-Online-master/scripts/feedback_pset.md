1.
What was unclear or difficult? (e.g. instructions, problems, videos, layout, etc.)

2.
What was clear or easy?

3.
Did you feel prepared to solve the problems? Why or why not?

4.
Did you need to use additional resources? If so, which ones?
