## W2D3
Strings vs Arrays and Debugging
+ [Strings vs Arrays][strings-vs-arrays]
+ [Debugging][debugging]
+ [Problem Set][problem-set]

[strings-vs-arrays]: ./notes/strings_vs_arrays.md
[debugging]: ./notes/debugging.md
[problem-set]: ./problem_set.md
