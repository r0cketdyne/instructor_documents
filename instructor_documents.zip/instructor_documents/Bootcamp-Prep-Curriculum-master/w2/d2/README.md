## W2D2
Nested Loops, Multi-Arrays, and Data Modeling
+ [Nested Loops][nested-loops]
+ [Multidimensional Arrays][multi-arrays]
+ [Data Modeling][data-modeling]
+ [Data Model 1 Exercises][data-model-1]
+ [Data Model 2 Exercises][data-model-2]
+ [Problem Set][problem-set]

[nested-loops]: ./notes/nested_loops.md
[multi-arrays]: ./notes/multidimensional_arrays.md
[data-modeling]: ./notes/nested_loops.md
[problem-set]: ./problem_set.md
[data-model-1]: ./data_model1.js
[data-model-2]: ./data_model2.js
