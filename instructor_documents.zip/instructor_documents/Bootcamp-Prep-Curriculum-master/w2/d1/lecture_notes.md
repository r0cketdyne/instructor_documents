# Review

### Primitive Data Types

### Functions

### Looping

### Conditionals

### Objects and Arrays

### Decomposition

### Abstraction
