# Mac Keyboard Shortcuts

## Command Line

Shortcut                        | Command
--------------------------------|-----------------------------------------
&#8984; + shift + ] / [         | Switch tab right/left
ctrl + A / E                    | Move cursor to beginning / end of line
ctrl + U / K                    | Delete to beginning / end of line
ctrl + W                        | Delete to start of word
ctrl + C                        | Terminate command
option + &#8592; &#8594;        | Move cursor one word left / right
&#8593; &#8595;                 | Navigate command history
&#8984; + K                     | Clear command history
