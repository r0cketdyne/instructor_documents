## Lecture Videos

The password to all videos: **go_bootcamp_go**

### Week 1
+ [w1d1](https://vimeo.com/165513328)
+ [w1d2](https://vimeo.com/165338384)
+ [w1d3](https://vimeo.com/165461927)
+ [w1d4](https://vimeo.com/165601487)

### Week 2
+ [w2d2](https://vimeo.com/166237715)
+ [w2d3](https://vimeo.com/163014203)
+ [w2d4](https://vimeo.com/163040194)

### Week 3
+ w3d2
  + [Part 1](https://vimeo.com/163589956)
  + [Part 2](https://vimeo.com/163589957)
  + [Part 3](https://vimeo.com/163589954)
  + [Part 4](https://vimeo.com/163589955)
+ [w3d3](https://vimeo.com/167228603)
+ [w3d4](https://vimeo.com/167447982)
