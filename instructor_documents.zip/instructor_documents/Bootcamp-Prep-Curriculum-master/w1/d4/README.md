### W1D4
Objects and Mocha testing
+ [Objects][objects]
+ [Object Methods][object-methods]
+ [Mocha][mocha]
+ [Cookie Monster Project][cookie-monster]
+ [Problem Set][problem-set]

[objects]: ./notes/objects.md
[object-methods]: ./notes/object_methods.md
[mocha]: ./notes/mocha.md
[cookie-monster]: ./cookieMonster/README.md
[problem-set]: ./problem_set.md
