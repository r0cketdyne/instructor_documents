### W1D5
+ [Review][review]
+ [Taking Assessments][taking-assessments]

[review]: ./review.js
[taking-assessments]: ./taking_assessments.md
