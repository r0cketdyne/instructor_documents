## W1D3
 Arrays and Controlling complexity
+ [Arrays][arrays]
+ [Controlling Complexity][controlling-complexity]
+ [Problem Set][problem-set]

[arrays]: ./notes/arrays.md
[controlling-complexity]: ./notes/controlling_complexity.md
[problem-set]: ./problem_set
