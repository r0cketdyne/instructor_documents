## W1D1
Welcome to Bootcamp Prep!
+ [Running JavaScript][running-javascript]
+ [Understanding Examples][understanding-examples]
+ [Data Types][data-types]
+ [Variables][variables]
+ [Functions][functions]
+ [Problem Set][problem-set]

[running-javascript]: ./notes/running_javascript.md
[data-types]: ./notes/data_types.md
[understanding-examples]: ./notes/understanding_examples.md
[variables]: ./notes/variables.md
[functions]: ./notes/functions.md
[problem-set]: ./problem_set.md
