# Review

### Multi-Dimensional Array
### Nested Looping
### `String.prototype.slice`
### Why is styling your code important?
### What is scope?
### Global Scope
### How are new scopes created?
### Function Scope
### `this`
