# Solutions

For the love of your own brain, **do not look at these before you
complete the day's assignments**. You'll only cheat yourself out of
learning the material. Becoming a good developer means learning how to
figure out what you don't know how to do, not just to look up the answer
in a book.

**Don't ever bother memorizing any specific solution in this class**. You will learn best
by practicing constantly. You'll struggle with some exercises:
struggle with them more, and ask for help.

Finally, when you've done the exercises, **absolutely look at the solutions
to see how I would have done it**.
