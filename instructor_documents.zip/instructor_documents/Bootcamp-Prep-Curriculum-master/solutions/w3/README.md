[Clock Project Solution Video: Part #1](https://vimeo.com/186040354)<br>
[Clock Project Solution Video: Part #2](https://vimeo.com/186040355)

[Sentiment Detector Solution Video](https://vimeo.com/184937883)


