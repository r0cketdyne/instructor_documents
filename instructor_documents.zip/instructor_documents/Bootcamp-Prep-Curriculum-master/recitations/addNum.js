function addNum(num1, num2) {
    var sum = num1 + num2;
    return sum;
}


console.log(addNum(1,1));
