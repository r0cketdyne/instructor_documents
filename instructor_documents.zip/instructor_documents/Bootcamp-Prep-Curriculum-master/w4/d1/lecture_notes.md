# Review

### Data Modeling
### Closures
### Callbacks
### High-Order Functions
### Asynchronous Programming
