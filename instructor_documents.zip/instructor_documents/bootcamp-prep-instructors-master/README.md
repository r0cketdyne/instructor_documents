## Bootcamp Prep Instructors

Roles:
  + [Live Instructors][live-instructors]
  + [TAs][teaching-assistants]

[Curriculum Highlights][curriculum-highlights]

[live-instructors]: ./live_instructors
[teaching-assistants]: ./teaching_assistants
[curriculum-highlights]: ./misc/curriculum_highlights.md
