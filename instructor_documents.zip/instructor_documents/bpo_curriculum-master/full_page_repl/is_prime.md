<instructions>
Write a function `isPrime(n)` that takes in a number and returns a boolean
indicating whether or not the number is a prime.

Difficulty: Medium
</instructions>

```repl-javascript
// Examples:
//
// isPrime(-5); // => false
// isPrime(2);  // => true
// isPrime(4);  // => false
// isPrime(9);  // => false
// isPrime(1);  // => true

function isPrime(n) {
  // your code here...
}
```
