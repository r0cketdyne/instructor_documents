# Javascript Node Quiz

<quiz>
  <question>
    <p>Why Learn Javascript?</p>
    <answer>It’s one of the most popular programming languages today. JavaScript is the language of the internet and the internet is ubiquitous.</answer>
    <answer>Every Bootcamp will allow you to go through their application process using JavaScript.</answer>
    <answer>It's a great vehicle to learn how to solve problems using programming.</answer>
    <answer correct>All of the above.</answer>
    <explanation>All Answers are correct!</explanation>
  </question>
</quiz>

<quiz>
  <question>
    <p>What does REPL stand for?</p>
    <answer>Ricky, Eric, Peter Loop</answer>
    <answer correct>Read, Evaluate, Print Loop</answer>
    <answer>Repeat, Evaluate, Programming Loop</answer>
    <answer>Recursive Evaluation Programming Language</answer>
    <explanation>Read input, evaluate that input, print the evaluation and then ask for input again.</explanation>
  </question>
</quiz>

<quiz>
  <question multiple>
    <p>What is Node?</p>
    <answer correct>A Javascript Runtime</answer>
    <answer>A text edirot for Javascript</answer>
    <answer correct>A way to run JavaScript outside the browser</answer>
    <explanation>Node is a javascript runtime environment and is not tied to a web browser.</explanation>
  </question>
</quiz>