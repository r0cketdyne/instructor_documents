## Test Driven Development: isPrime Lecture

<iframe src="https://player.vimeo.com/video/246870568" width="100%" height="480" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>

## TDD: isPrime Refactor

<iframe src="https://player.vimeo.com/video/246870596" width="100%" height="480" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
