<p id=course_description>Bootcamp Prep Online is a self paced course, guaranteed to get you accepted at the most selective coding schools or your money back.</p>

![alt text][image]

[image]: images/bootcamp_prep.png "Bootcamp Prep"