## Mock Interviews

We offer mock interviews for each Bootcamp Prep graduate! We highly encourage you
to take advantage of these. They will be administered just a like a real App Academy
admissions technical interview. These are for practice. Your performance on these mock
interviews has no bearing on your actual application, so you have nothing to lose.
This is a great opportunity to get some invaluable interview experience.
You can schedule a mock interview in your profile page. To access your profile,
click on your use icon in the top right.

Best of luck!
