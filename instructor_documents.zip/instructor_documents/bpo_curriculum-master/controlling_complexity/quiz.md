<quiz>
  <question>
    <p>Why is it good to decompose complex problems?</p>
    <answer>because small chunks of the problem will be easier to solve</answer>
    <answer>because our code will be clearer and more elegant</answer>
    <answer>because it will allow us to explain our solution easier</answer>
    <answer correct> all of the above</answer>  
    <explanation>Decomposition is often times the key to solving really tricky problems and has all these benefits</explanation>
  </question>
</quiz>

<quiz>
  <question>
    <p>How do you know when to decompose by creating a separate helper function?</p>
    <answer>when you find a sub-problem that can be isolated</answer>
    <answer>when the current function you are writing is becoming too long and hard to understand</answer>
    <answer correct>both of the above</answer>
    <explanation>We create helper functions to solve sub-problems and keep our code clean!</explanation>
  </question>
</quiz>
