## Keep Practicing

To prepare for a technical interview, it is important to get as much practice as you can. Experience solving new problems is invaluable and will help boost your confidence in a bootcamp interview.

You may find some of these upcoming problems challenging. Remember that the problems that *you* find challenging are the ones worth practicing. Focus on your weaknesses so you can rock those interviews!

As always, feel free to look at the solutions and videos if you get stuck. But be sure that you are able to code it on your own before moving on to the next problem. Test yourself!
