<download href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_3/A3.zip">Assessment Three</download>

<download submitted href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_3/A3_solution.zip">Assessment Three Solution</download>

<a href="https://vimeo.com/212515904">My Index Of</a>
<a href="https://vimeo.com/212515890">Min Max Difference</a>
<a href="https://vimeo.com/212515874">Divisible By</a>
<a href="https://vimeo.com/212515861">Dynamic Fizz Buzz</a>
<a href="https://vimeo.com/212515847">Magic Cipher</a>

<upload href="">Upload Your Assessment</upload>
