<download href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_7/A7.zip">Assessment Seven</download>

<download submitted href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_7/A7_solution.zip">Assessment Seven Solution</download>

<a href="https://vimeo.com/212646721">Number Primes</a>
<a href="https://vimeo.com/212646692">Longest Bigram</a>
<a href="https://vimeo.com/212646651">Longest Letter Streak</a>
<a href="https://vimeo.com/212646629">Previous Prime Array</a>

<upload href="">Upload Your Assessment</upload>
