<download href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_6/A6.zip">Assessment Six</download>

<download submitted href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_6/A6_solution.zip">Assessment Six Solution</download>

<a href="https://vimeo.com/212515670">My Map</a>
<a href="https://vimeo.com/212515655">Is Palindrome</a>
<a href="https://vimeo.com/212515640">Passing Students</a>
<a href="https://vimeo.com/213127281">Laligat Array</a>
<a href="https://vimeo.com/212515590">Disemvowel</a>

<upload href="">Upload Your Assessment</upload>
