<download href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_2/A2.zip">Assessment Two</download>

<download submitted href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_2/A2_solution.zip">Assessment Two Solution</download>

<a href="https://vimeo.com/212515979">Reverse Range</a>
<a href="https://vimeo.com/212515970">Is Prime</a>
<a href="https://vimeo.com/212515961">Magic Numbers</a>
<a href="https://vimeo.com/212515949">First and Last</a>
<a href="https://vimeo.com/212515920">Royal We</a>

<upload href="">Upload Your Assessment</upload>
