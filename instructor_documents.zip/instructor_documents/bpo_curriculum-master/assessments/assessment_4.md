<download href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_4/A4.zip">Assessment Four</download>

<download submitted href="https://s3-us-west-1.amazonaws.com/aao-bpo/assessments/assessment_4/A4_solution.zip">Assessment Four Solution</download>

<a href="https://vimeo.com/212515826">Array Builder</a>
<a href="https://vimeo.com/212515816">Longest Word</a>
<a href="https://vimeo.com/212515802">Least Common Multiple</a>
<a href="https://vimeo.com/212515793">Silly Cipher</a>
<a href="https://vimeo.com/212515762">Hipsterfy</a>

<upload href="">Upload Your Assessment</upload>
