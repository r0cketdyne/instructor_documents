## Bootcamp Prep Online Tier Admissions Test

Below is selected content from an early chapter of the Bootcamp Prep Online course.
The material assumes that you have some basic knowledge of JavaScript programming.
If you have zero JavaScript programming experience, please complete [Codecademy's JavaScript Course][codecademy]
to get your feet wet first. After completing that course, come back to this material
and complete the evaluation.

The following lectures and readings are designed to give you a preview of what to
expect during the course. After going through these materials there will be a short
evaluation to test what you have learned. No need to rush through the material though,
Feel free to reread the notes and replay the videos! Make sure you have a good understanding
of the concepts before attempting the evaluation.


[codecademy]: https://www.codecademy.com/learn/javascript
