After digesting the material in the previous sections, complete the following exercises
You may test your code before submitting it. You can also reference the notes
in these sections before submitting.


https://repl.it/classroom/invite/DM4sTgN
