## Scoping Walkthrough

<iframe src="https://player.vimeo.com/video/209961037" width="100%" height="480" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
