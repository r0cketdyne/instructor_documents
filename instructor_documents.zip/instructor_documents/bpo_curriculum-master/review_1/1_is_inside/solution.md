## isInside Walkthrough

<iframe src="https://player.vimeo.com/video/210321209" width="100%" height="400" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>

## Solution Code

```js
function isInside(array, ele) {
  return array.indexOf(ele) > -1;
}
```
