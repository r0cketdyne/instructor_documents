## Practice Assessment 3

<a href="https://s3-us-west-1.amazonaws.com/aao-bpo/practice_assessments/practice_3/P3.zip">Download Practice 3</a>

<a href="https://s3-us-west-1.amazonaws.com/aao-bpo/practice_assessments/practice_3/P3_solution.zip">Download Practice 3 Solution</a>
