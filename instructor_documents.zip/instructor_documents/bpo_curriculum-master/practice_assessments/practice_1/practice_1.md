## Practice Assessment 1

Time for a practice assessment! Feel free to check out solution after you give it an
honest attempt. Use the video walkthroughs in the following sections to ease your understanding.
Before moving on from studying this practice assessment, be sure that you can complete it by yourself.
**Don't just watch the videos and assume that you will be able to solve these problems on your own.**
Be honest with yourself. Prove that you can solve it on your own by testing yourself.
The practice assessments will be similar to the following real assessments, so study hard!

<a href="https://s3-us-west-1.amazonaws.com/aao-bpo/practice_assessments/practice_1/P1.zip">Download Practice 1</a>

<a href="https://s3-us-west-1.amazonaws.com/aao-bpo/practice_assessments/practice_1/P1_solution.zip">Download Practice 1 Solution</a>
