## Conditionals Lecture

<iframe src="https://player.vimeo.com/video/207694216" width="100%" height="480" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>

**Note:** It's okay if functions are unfamiliar right now, we'll study them next section!
