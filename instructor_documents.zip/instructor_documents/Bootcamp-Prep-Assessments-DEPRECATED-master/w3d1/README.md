Here are links to solution videos for the 2nd Monday assessment; the password to these videos is "__go\_bootcamp\_go__".

- [Week 3 Monday Assessment - Problem #1: "myIndexOf”](https://vimeo.com/178111084)
- [Week 3 Monday Assessment - Problem #2: "Min Max Product”](https://vimeo.com/178111456)
- [Week 3 Monday Assessment - Problem #3: "Least Common Multiple”](https://vimeo.com/178111088)
- [Week 3 Monday Assessment - Problem #4: "Hipsterfy”](https://vimeo.com/178111089)
- [Week 3 Monday Assessment - Problem #5: "Magic Cipher”](https://vimeo.com/178111090)
