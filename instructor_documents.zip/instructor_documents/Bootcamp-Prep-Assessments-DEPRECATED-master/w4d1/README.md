Here are the solution videos to the third and last Monday assessment; the password is "__go\_bootamp\_go__".

- [Week 4 Monday Assessment - Problem #1: "myForEach”](https://vimeo.com/178111576)
- [Week 4 Monday Assessment - Problem #2: "myMap”](https://vimeo.com/178111585)
- [Week 4 Monday Assessment - Problem #3: "passingStudents”](https://vimeo.com/178111598)
- [Week 4 Monday Assessment - Problem #4: "Laligat Sequence (pt. 1)”](https://vimeo.com/178111602)
- [Week 4 Monday Assessment - Problem #4: "Laligat Sequence (pt. 2)”](https://vimeo.com/178111607)
