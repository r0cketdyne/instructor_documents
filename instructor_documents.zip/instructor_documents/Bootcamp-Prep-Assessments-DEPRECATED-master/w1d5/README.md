## Assessment 01 Solutions
+ [range](https://vimeo.com/162108805) (7:10)
+ [unique](https://vimeo.com/162135215) (5:52)
+ [elementCount](https://vimeo.com/162135199) (7:36)
+ [reverseSentence](https://vimeo.com/162135219) (7:33)
+ [fizzBuzz](https://vimeo.com/162135209) (3:47)

The password to all videos: **go_bootcamp_go**
