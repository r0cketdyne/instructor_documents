Here are Vimeo links to solution videos from this assessment. 


The password is: __go\_bootcamp\_go__



> [Problem #1: “Royal We”](https://vimeo.com/177761751)
<br>
[Problem #2: “Element Count”](https://vimeo.com/177764706)
<br>
[Problem #3: “Reverse Range”](https://vimeo.com/177761754)
<br>
[Problem #4: “Reverse Sentence”](https://vimeo.com/177764713)
<br>
[Problem #5: “Magic Numbers”](https://vimeo.com/177761755)
