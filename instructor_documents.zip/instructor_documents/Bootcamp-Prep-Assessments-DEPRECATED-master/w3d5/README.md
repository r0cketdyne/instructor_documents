## Assessment 05 Solutions
+ [myForEach](https://vimeo.com/163840454) (4:58)
+ [mySelect](https://vimeo.com/163840456) (5:21)
+ [inPigLatin](https://vimeo.com/163840452) (19:38)

The password to all videos: **go_bootcamp_go**
