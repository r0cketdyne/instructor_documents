## Assessment 03 Solutions
+ [divisibleByFivePairSum](https://vimeo.com/163018573) (6:59)
+ [myIndexOf](https://vimeo.com/163018577) (4:00)
+ [mixMaxDifference](https://vimeo.com/163018574) (4:26)
+ [magicCipher](https://vimeo.com/163018572) (7:58)
+ [dynamicFizzBuzz](https://vimeo.com/163018571) (3:18)

The password to all videos: **go_bootcamp_go**
