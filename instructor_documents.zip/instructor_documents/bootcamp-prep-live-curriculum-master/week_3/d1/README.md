## W3D1

+ Assessment 4
+ Assessment Review
+ [Problem Set][w3d1-pset]

### Homework

+ Complete the [Problem Set][w3d1-pset]
+ Complete and submit a fully corrected Assessment 4 by W3D5's class.

### Videos

+ Problem Walkthroughs
  + [objectSize](https://vimeo.com/213908306/508649cca4)
  + [threeInARow](https://vimeo.com/221020709/d75d01e206)
  + [threeIncreasing](https://vimeo.com/221328711/c2eea36101)
  + [power](https://vimeo.com/213908270/8dad4c3c68)
  

[w3d1-pset]: ./w3d1_pset.zip
