## Week 1

+ [Day 1][d1]
+ [Day 2][d2]
+ [Day 3][d3]
+ [Day 4][d4]
+ [Day 5][d5]


[d1]: ./d1
[d2]: ./d2
[d3]: ./d3
[d4]: ./d4
[d5]: ./d5
