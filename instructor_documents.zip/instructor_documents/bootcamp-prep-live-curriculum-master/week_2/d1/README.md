## W2D1

+ Assessment 2
+ Assessment Review

+ [New Problem Set Format][pset-format]
+ [Problem Set][w2d1-pset]

### Homework

+ Complete the [Problem Set][w2d1-pset]
+ Complete and submit a fully corrected Assessment 2 by W2D5's class.

### Videos

+ Problem Walkthroughs
  + [mirrorArray](https://vimeo.com/213729885/d3ae036012)
  + [avgValue](https://vimeo.com/213729859/9211c5ec88)
  + [abbreviate](https://vimeo.com/214906790/9fea0547f1)
  + [firstLastCap](https://vimeo.com/221328473/76dc43b3ce)

[w2d1-pset]: ./w2d1_pset.zip
[pset-format]: ./problem_set_format.md
