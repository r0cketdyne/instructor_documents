## W2D5

+ [Problem Set][w2d5-pset]
+ Assessment 3!


### Homework

+ Complete the [problem set][w2d5-pset]
+ Complete and submit a fully corrected Assessment 3 by W2D1's class.
+ Study [Practice Assessment 4][practice-4] to prep for the upcoming W3D1 assessment.

### Videos

+ Problem Walkthroughs
  + [longWordCount](https://vimeo.com/209638787/72f6e85e1e)
  + [factorial](https://vimeo.com/209638682/0dd8adea77)
  + [leastCommonMultiple](https://vimeo.com/209638756/664dedbc06)
  + [hipsterfy](https://vimeo.com/209638705/bcfb6a056d)

[w2d5-pset]: ./w2d5_pset.zip
[practice-4]: /practice_assessments/practice_4
