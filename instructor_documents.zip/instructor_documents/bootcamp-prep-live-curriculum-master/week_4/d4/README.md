## W4D4

+ Assessment 7


+ [What's Next][whats-next] and bootcamp Q/A

+ [Problem Set][w4d4-pset]


### Homework

+ Complete the [Problem Set][w4d4-pset]
+ No need to submit corrections for Assessment 7, but you should still study it.
+ Tomorrow (W4D5) we will have a final assessment for 1.5 hours
  + You will be unable to ask for hints or help solving the problems
  + You may only ask for help running mocha, etc..

### Videos

+ Problem Walkthroughs
  + [maxAdjacentSum](https://vimeo.com/214901577/7e52b670cf)
  + [opposingSums](https://vimeo.com/214901239/9046bb44ea)
  + [additionSequence](https://vimeo.com/221328306/e1a24b470a)
  + [reverseString](https://vimeo.com/248528876/0f86c74e8c)
  + [flatten](https://vimeo.com/251869891/3368228d04)

[whats-next]: ./notes/whats_next.md
[w4d4-pset]: ./w4d4_pset.zip
