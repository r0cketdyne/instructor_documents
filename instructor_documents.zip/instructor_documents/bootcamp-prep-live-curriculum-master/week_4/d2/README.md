## W4D2

+ [Driver-Navigator Pair Instructions][pairing-instructions]


+ [Problem Set][w4d2-pset]

### Homework

+ Complete the [Problem Set][w4d2-pset]

### Videos

+ Problem Walkthroughs
  + [safeSpeedChange](https://vimeo.com/228423735/052677a54c)
  + [isUniqueAnagram](https://vimeo.com/211377928/a65bd028f7)
  + [reverseHipsterfy](https://vimeo.com/220369665/fa81b24b43)
  + [winningHand](https://vimeo.com/214723755/02e3ba733d)
  + [shiftChars](https://vimeo.com/211376064/c18d3e4e18)
  + [uncompressString](https://vimeo.com/214575553/64df2faab6)
  + [fibonacci](https://vimeo.com/211544248/4fa67361f9)


[pairing-instructions]: ./pairing_instructions.md
[w4d2-pset]: ./w4d2_pset.zip
