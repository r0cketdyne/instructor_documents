## Bonus Material

In this folder we have provided bonus content for you to consume on your own. You'll
find some additional problems and new topics inside. This material is advanced and
step above what will be required of you on an interview but if you are looking for
a challenge you are welcome to jump in.

**You should not spend time on this bonus material if you do not feel 100%
comfortable with the core weekly material**. If you master the material in the
weekly folders, you'll be ready crush your interviews. Prioritize understanding
the weekly material, and then come back to these bonuses.
