### Practice 1 Videos
+ [evenRange](https://vimeo.com/235417325/6a0982bcf2)
+ [reverseString](https://vimeo.com/235422686/220f70cf1f)
+ [intersect](https://vimeo.com/235420458/2cc489f2d2)
+ [fuzzBizz](https://vimeo.com/235417888/1c417fbc7d)
+ [arrayRange](https://vimeo.com/235416321/975ec7b931)
