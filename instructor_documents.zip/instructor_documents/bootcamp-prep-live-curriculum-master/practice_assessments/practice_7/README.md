### Practice 7 Videos
+ [primeFactors](https://vimeo.com/235421501/a6515febac)
+ [bigramArray](https://vimeo.com/235416815/7fd83b9c22)
+ [bestWinStreak](https://vimeo.com/236813077/74b971e1c2)
+ [nextPrimeArray](https://vimeo.com/236813428/6781e603fe)
