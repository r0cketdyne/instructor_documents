### Practice 5 Videos
+ [isPassing](https://vimeo.com/235784156/17a5f685d1)
+ [variableNameify](https://vimeo.com/235426476/0afd073902)
+ [reverse2D](https://vimeo.com/235425143/ace81d9b4b)
+ [productCallback](https://vimeo.com/235424515/b48fbe368e)
+ [greaterCallback](https://vimeo.com/236810371/30264b910b)
