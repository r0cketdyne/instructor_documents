### Practice 6 Videos
+ [myFind](https://vimeo.com/235421017/695873830f)
+ [hasSymmetry](https://vimeo.com/235789098/7e2fc1369b)
+ [totalNumProblems](https://vimeo.com/235422053/fa41f32017)
+ [evenSumArray](https://vimeo.com/236811879/4ea8db2bad)
+ [numToWords](https://vimeo.com/235790669/b949f28e79)
