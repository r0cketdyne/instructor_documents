### Practice 3 Videos
+ [isElement](https://vimeo.com/236640759/3a5a6cbe47)
+ [minMaxProduct](https://vimeo.com/235418140/7f89ab8c4c)
+ [phraseFinder](https://vimeo.com/235791260/f8fda70747)
+ [multiples](https://vimeo.com/235784157/472c9483aa)
+ [valueReplace](https://vimeo.com/235425678/2164c487d3)
