### Practice 2 Videos
+ [reverseOddRange](https://vimeo.com/236637440/2a1e9b3196)
+ [isSquare](https://vimeo.com/235790284/70a3e882ea)
+ [mysticNumbers](https://vimeo.com/235420825/561d65411c)
+ [firstOrLast](https://vimeo.com/235416566/d4ec866888)
+ [fromMeToYou](https://vimeo.com/235417606/1019a1442d)
