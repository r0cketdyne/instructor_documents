### Practice 4 Videos
+ [objectToString](https://vimeo.com/235423102/4dfa9cbbe6)
+ [shortestWord](https://vimeo.com/235792154/884647b581)
+ [greatestCommonFactor](https://vimeo.com/235418743/cfe03924bb)
+ [valueConcat](https://vimeo.com/236808198/b98d4949a0)
+ [hipsterfyWord](https://vimeo.com/235419336/ac21a25a2c)
