## Assessment Video Solutions

password: **go_bootcamp_go**

### Assessment 1
+ [range](https://vimeo.com/212516068)
+ [reverseSentence](https://vimeo.com/212516050)
+ [unique](https://vimeo.com/212516029)
+ [fizzBuzz](https://vimeo.com/212516003)
+ [stringRange](https://vimeo.com/212515985)

### Assessment 2
+ [reverseRange](https://vimeo.com/212515979)
+ [isPrime](https://vimeo.com/212515970)
+ [magicNumber](https://vimeo.com/212515961)
+ [firstAndLast](https://vimeo.com/212515949)
+ [royalWe](https://vimeo.com/212515920)

### Assessment 3
+ [myIndexOf](https://vimeo.com/212515904)
+ [minMaxDifference](https://vimeo.com/212515890)
+ [divisibleBy](https://vimeo.com/212515874)
+ [dynamicFizzBuzz](https://vimeo.com/212515861)
+ [magicCipher](https://vimeo.com/212515847)

### Assessment 4
+ [arrayBuilder](https://vimeo.com/212515826)
+ [longestWord](https://vimeo.com/212515816)
+ [leastCommonMultiple](https://vimeo.com/212515802)
+ [sillyCipher](https://vimeo.com/212515793)
+ [hipsterfy](https://vimeo.com/212515762)

### Assessment 5
+ [highestScore](https://vimeo.com/212515746)
+ [snakeToCamel](https://vimeo.com/212515728)
+ [sum2DArray](https://vimeo.com/212515710)
+ [minValueCallback](https://vimeo.com/212515696)
+ [mySelect](https://vimeo.com/212515682)

### Assessment 6
+ [myMap](https://vimeo.com/212515670)
+ [isPalindrome](https://vimeo.com/212515655)
+ [passingStudents](https://vimeo.com/212515640)
+ [laligatArray](https://vimeo.com/213127281)
+ [disemvowel](https://vimeo.com/212515590)

### Assessment 7
+ [numberPrimes](https://vimeo.com/212646721)
+ [longestBigram](https://vimeo.com/212646692)
+ [longestLetterStreak](https://vimeo.com/212646651)
+ [previousPrimeArray](https://vimeo.com/212646629)
