## Practice Assessment Solution Videos

### Practice 1 Videos
+ [evenRange](https://vimeo.com/235417325/6a0982bcf2)
+ [reverseString](https://vimeo.com/235422686/220f70cf1f)
+ [intersect](https://vimeo.com/235420458/2cc489f2d2)
+ [fuzzBizz](https://vimeo.com/235417888/1c417fbc7d)
+ [arrayRange](https://vimeo.com/235416321/975ec7b931)

### Practice 2 Videos
+ [reverseOddRange](https://vimeo.com/236637440/2a1e9b3196)
+ [isSquare](https://vimeo.com/235790284/70a3e882ea)
+ [mysticNumbers](https://vimeo.com/235420825/561d65411c)
+ [firstOrLast](https://vimeo.com/235416566/d4ec866888)
+ [fromMeToYou](https://vimeo.com/235417606/1019a1442d)

### Practice 3 Videos
+ [isElement](https://vimeo.com/236640759/3a5a6cbe47)
+ [minMaxProduct](https://vimeo.com/235418140/7f89ab8c4c)
+ [phraseFinder](https://vimeo.com/235791260/f8fda70747)
+ [multiples](https://vimeo.com/235784157/472c9483aa)
+ [valueReplace](https://vimeo.com/235425678/2164c487d3)

### Practice 4 Videos
+ [objectToString](https://vimeo.com/235423102/4dfa9cbbe6)
+ [shortestWord](https://vimeo.com/235792154/884647b581)
+ [greatestCommonFactor](https://vimeo.com/235418743/cfe03924bb)
+ [valueConcat](https://vimeo.com/236808198/b98d4949a0)
+ [hipsterfyWord](https://vimeo.com/235419336/ac21a25a2c)

### Practice 5 Videos
+ [isPassing](https://vimeo.com/235784156/17a5f685d1)
+ [variableNameify](https://vimeo.com/235426476/0afd073902)
+ [reverse2D](https://vimeo.com/235425143/ace81d9b4b)
+ [productCallback](https://vimeo.com/235424515/b48fbe368e)
+ [greaterCallback](https://vimeo.com/236810371/30264b910b)

### Practice 6 Videos
+ [myFind](https://vimeo.com/235421017/695873830f)
+ [hasSymmetry](https://vimeo.com/235789098/7e2fc1369b)
+ [totalNumProblems](https://vimeo.com/235422053/fa41f32017)
+ [evenSumArray](https://vimeo.com/236811879/4ea8db2bad)
+ [numToWords](https://vimeo.com/235422053/fa41f32017)

### Practice 7 Videos
+ [primeFactors](https://vimeo.com/235421501/a6515febac)
+ [bigramArray](https://vimeo.com/235416815/7fd83b9c22)
+ [bestWinStreak](https://vimeo.com/236813077/74b971e1c2)
+ [nextPrimeArray](https://vimeo.com/236813428/6781e603fe)
